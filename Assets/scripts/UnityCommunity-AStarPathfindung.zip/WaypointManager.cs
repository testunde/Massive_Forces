using UnityEngine;
using System.Collections;

namespace Scripts {
public class WaypointManager:MonoBehaviour
{
public float maxDistanceBetweenWaypoints = 5.0f;
void Awake()
{
  Waypoint.Waypoints = new ArrayList();
  CalculateWaypoints(transform);
  CalculateNeighbours();
}
void CalculateWaypoints(Transform parentTransform)
{
  foreach(Transform child in parentTransform)
  {

   if(child.GetComponent<Waypoint>())
   {

        Waypoint wP = child.GetComponent<Waypoint>();
        Waypoint.Waypoints.Add(wP);

   }
   if(child.childCount > 0)
   {

        CalculateWaypoints(child);

   }

  }
}

public void CalculateNeighbours()
{

  foreach(Waypoint waypoint in Waypoint.Waypoints)
  {

   foreach(Waypoint neighbour in Waypoint.Waypoints)
   {

        if(neighbour!=waypoint)
        {
  
         Vector3 pos1 = waypoint.transform.position;
         Vector3 pos2 = neighbour.transform.position;
         float  deltaL = Vector3.Distance(pos1,pos2);
  
         if(deltaL <=maxDistanceBetweenWaypoints)
         {
          RaycastHit[] hits;
          hits = Physics.RaycastAll(pos1,Vector3.Normalize(pos2-pos1),deltaL);
        
          bool isWayFree = true;
        
          for(int i = 0; i < hits.Length;i++)
          {
        
           if(!hits[i].collider.isTrigger)
           {
        
                isWayFree = false;
                break;
           }
        
          }
        
        
          if(isWayFree)
          {
           waypoint.addNeighbour(neighbour);
        
          }
  
         }
  
        }

   }



  }
}
}
}
