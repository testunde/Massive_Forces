using UnityEngine;
using System.Collections;

namespace Scripts {
public class PathNode:ScriptableObject
{
                public float fValue = 0f;
                public float gValue = 0f;
                public float hValue = 0f;       
                public PathNode parentPathNode;
                public Waypoint waypoint;
}
}
