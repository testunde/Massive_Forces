using UnityEngine;
using System.Collections;

namespace Scripts {
public class Waypoint:MonoBehaviour
{
public static ArrayList Waypoints = new ArrayList();
public ArrayList waypointsInRange;

public void addNeighbour(Waypoint neighbour)
{
  if(waypointsInRange==null)
{

  waypointsInRange = new ArrayList();

}

waypointsInRange.Add(neighbour);
}

void Awake()
{

  transform.GetComponent<Renderer>().enabled = false;

}

void OnDrawGizmosSelected ()
{

  Gizmos.color =new Color (0,1,1,0.5f);
  Gizmos.DrawCube (transform.position, new Vector3 (0.5f,0.2f,0.5f));

  if(waypointsInRange!=null && waypointsInRange.Count > 0)
  {

   foreach(Waypoint neighbour in waypointsInRange)
   {
         Gizmos.color = new Color(1,0,0,1);
         Gizmos.DrawLine(transform.position,neighbour.transform.position);

   }

  }

}

}
}
