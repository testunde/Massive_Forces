using UnityEngine;
using System.Collections;

namespace Scripts {
public class PathFinder : MonoBehaviour{

static public ArrayList GetPath(Waypoint startWaypoint, Waypoint targetWaypoint)
{
                ArrayList openList = new ArrayList();
                ArrayList closedList = new ArrayList();
                PathNode currentPathNode;
                PathNode startField = (PathNode)ScriptableObject.CreateInstance<PathNode>();
                startField.waypoint = startWaypoint;
                PathNode targetField = null;
                ArrayList pathArray = new ArrayList();
                currentPathNode = startField;
                openList.Add(startField);


                if(startWaypoint != targetWaypoint)
                {
                 while(targetField == null && openList.Count > 0)
                        {
                                int index = ReturnPathNodeWithLowestFValue(openList);
                                currentPathNode = (PathNode)openList[index];
                                openList.RemoveAt(index);
                                closedList.Add(currentPathNode);

                                ArrayList neighbourWaypoints = currentPathNode.waypoint.waypointsInRange;

                                for(int i = 0; i < neighbourWaypoints.Count; i++)
                                {
                                 if(!IsInCL(closedList,(Waypoint)neighbourWaypoints[i]))
                                        {
                                         int indexInOL = IsInOL(openList,(Waypoint)neighbourWaypoints[i]);

                                                if(indexInOL >= 0)//Wenn der Wegpunkt in der openList ist
                                                {
                                                 float newGValue = currentPathNode.gValue +Vector3.Distance(currentPathNode.waypoint.transform.position,((PathNode)openList[indexInOL]).waypoint.transform.position);

                                                        if(newGValue < ((PathNode)openList[indexInOL]).gValue)
                                                        {       
                                                   ((PathNode)openList[indexInOL]).parentPathNode = currentPathNode;
                                                   ((PathNode)openList[indexInOL]).gValue = newGValue;
                                                   ((PathNode)openList[indexInOL]).fValue = (newGValue +((PathNode)openList[indexInOL]).hValue);
                                                        }
                                                }
                                                else//Wenn der Wegpunkt nicht in der openList ist
                                                {                                       
                                                        float GValue =  currentPathNode.gValue + Vector3.Distance(currentPathNode.waypoint.transform.position, ((Waypoint)neighbourWaypoints[i]).transform.position);
                                                        float HValue = Vector3.Distance(((Waypoint)neighbourWaypoints[i]).transform.position, targetWaypoint.transform.position);
                                                        float FValue = GValue + HValue;

                                                        PathNode newPathNode = (PathNode)ScriptableObject.CreateInstance<PathNode>();
                                                        newPathNode.waypoint = (Waypoint)neighbourWaypoints[i];
                                                        newPathNode.gValue = GValue;
                                                        newPathNode.hValue = HValue;
                                                        newPathNode.fValue = FValue;
                                                        newPathNode.parentPathNode = currentPathNode;

                                                        openList.Add(newPathNode);

                                                        if(newPathNode.waypoint == targetWaypoint)
                                                        {
                                                         targetField = newPathNode;
                                                         pathArray = ReturnPath(startField,targetField);
                                                                break;
                                                        }                       
}//else
}//if
}//for
}//while
                }
                return pathArray;
}

////////////////////////////////////////////////////////////////////////////

public static bool IsInCL(ArrayList closedL, Waypoint wayPoint)
{
                 bool  isIn = false;

                for(int i = 0;i<closedL.Count;i++)
                {

                                if(((PathNode)closedL[i]).waypoint == wayPoint)
                                {

                                                isIn = true;
                                                break;
                                }

                }
                return isIn;

}

////////////////////////////////////////////////////////////////////////////


static public int IsInOL(ArrayList openL, Waypoint wayPoint)
{

                int index = -1;

                for(int i = 0; i<openL.Count; i++)
                {

                                if(((PathNode)openL[i]).waypoint == wayPoint)
                                {

                                                index = i;
                                                break;
                                }

                }
                return index;
}

////////////////////////////////////////////////////////////////////////////

static public int ReturnPathNodeWithLowestFValue(ArrayList openL)
{
                PathNode pathNode = null;
                int index = -1;

                if(openL.Count >0)
                {

                                for(int i = 0; i < openL.Count; i++)
                                {

                                                if(index == -1)
                                                {

                                                                pathNode = (PathNode)openL[i];
                                                                index = i;
                                                }
                                                else if(pathNode.fValue > ((PathNode)openL[i]).fValue)
                                                {
                                                                pathNode = (PathNode)openL[i];
                                                                index = i;
                                                }

                                }

                }

                return index;
}

////////////////////////////////////////////////////////////////////////////

static public ArrayList ReturnPath(PathNode startField, PathNode targetField)
{
                ArrayList pathArray = new ArrayList();
                PathNode currentPathNode = targetField;

                while(currentPathNode != startField)
                {

                                pathArray.Add(currentPathNode.waypoint);
                                currentPathNode = currentPathNode.parentPathNode;
                }

                pathArray.Reverse();

                return pathArray;
}
}
}
